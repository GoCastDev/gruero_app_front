// import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from './assets/vite.svg'
// import heroImg from './assets/hero.png'
// import './App.css'

// function App() {
//   const [count, setCount] = useState(0)

//   return (
//     <>
//       <section id="center">
//         <div className="hero">
//           <img src={heroImg} className="base" width="170" height="179" alt="" />
//           <img src={reactLogo} className="framework" alt="React logo" />
//           <img src={viteLogo} className="vite" alt="Vite logo" />
//         </div>
//         <div>
//           <h1>Get started</h1>
//           <p>
//             Edit <code>src/App.jsx</code> and save to test <code>HMR</code>
//           </p>
//         </div>
//         <button
//           type="button"
//           className="counter"
//           onClick={() => setCount((count) => count + 1)}
//         >
//           Count is {count}
//         </button>
//       </section>

//       <div className="ticks"></div>

//       <section id="next-steps">
//         <div id="docs">
//           <svg className="icon" role="presentation" aria-hidden="true">
//             <use href="/icons.svg#documentation-icon"></use>
//           </svg>
//           <h2>Documentation</h2>
//           <p>Your questions, answered</p>
//           <ul>
//             <li>
//               <a href="https://vite.dev/" target="_blank">
//                 <img className="logo" src={viteLogo} alt="" />
//                 Explore Vite
//               </a>
//             </li>
//             <li>
//               <a href="https://react.dev/" target="_blank">
//                 <img className="button-icon" src={reactLogo} alt="" />
//                 Learn more
//               </a>
//             </li>
//           </ul>
//         </div>
//         <div id="social">
//           <svg className="icon" role="presentation" aria-hidden="true">
//             <use href="/icons.svg#social-icon"></use>
//           </svg>
//           <h2>Connect with us</h2>
//           <p>Join the Vite community</p>
//           <ul>
//             <li>
//               <a href="https://github.com/vitejs/vite" target="_blank">
//                 <svg
//                   className="button-icon"
//                   role="presentation"
//                   aria-hidden="true"
//                 >
//                   <use href="/icons.svg#github-icon"></use>
//                 </svg>
//                 GitHub
//               </a>
//             </li>
//             <li>
//               <a href="https://chat.vite.dev/" target="_blank">
//                 <svg
//                   className="button-icon"
//                   role="presentation"
//                   aria-hidden="true"
//                 >
//                   <use href="/icons.svg#discord-icon"></use>
//                 </svg>
//                 Discord
//               </a>
//             </li>
//             <li>
//               <a href="https://x.com/vite_js" target="_blank">
//                 <svg
//                   className="button-icon"
//                   role="presentation"
//                   aria-hidden="true"
//                 >
//                   <use href="/icons.svg#x-icon"></use>
//                 </svg>
//                 X.com
//               </a>
//             </li>
//             <li>
//               <a href="https://bsky.app/profile/vite.dev" target="_blank">
//                 <svg
//                   className="button-icon"
//                   role="presentation"
//                   aria-hidden="true"
//                 >
//                   <use href="/icons.svg#bluesky-icon"></use>
//                 </svg>
//                 Bluesky
//               </a>
//             </li>
//           </ul>
//         </div>
//       </section>

//       <div className="ticks"></div>
//       <section id="spacer"></section>
//     </>
//   )
// }

// export default App


// import { useEffect } from 'react';
// import { Header } from './components/layout/Header';
// import { NetworkListener } from './components/layout/NetworkListener';
// import { AssignmentModal } from './features/assignment/AssignmentModal';
// import { ProgressStepper } from './features/tracking/ProgressStepper';
// import { EvidenceDropzone } from './features/evidence/EvidenceDropzone';
// import { ServiceSuccess } from './features/evidence/ServiceSuccess';
// import { BottomNav } from './components/layout/BottomNav';
// import { MapComponent } from './components/ui/MapComponent';
// import { PermissionModal } from './components/permissions/PermissionModal';
// import { useServiceStore, ESTADOS_SERVICIO } from './store/useServiceStore';
// import { MapView, EarningsView, ProfileView } from './features/views/SecondaryViews';
// import { Truck } from 'lucide-react';

// export default function App() {
//   const cargarServicioPersistido = useServiceStore((state) => state.cargarServicioPersistido);
//   const asignarNuevoServicio = useServiceStore((state) => state.asignarNuevoServicio);
//   const estadoActual = useServiceStore((state) => state.estadoActual);
//   const servicioActivo = useServiceStore((state) => state.servicioActivo);
//   const tabActiva = useServiceStore((state) => state.tabActiva);

//   useEffect(() => {
//     cargarServicioPersistido();
//   }, [cargarServicioPersistido]);

//   const simularLlegadaServicio = () => {
//     asignarNuevoServicio({
//       id: '10928',
//       operador: 'Control Central',
//       cliente: { nombre: 'Carlos Mendoza', telefono: '04141234567' },
//       vehiculo: { marca: 'Toyota', modelo: 'Hilux', placa: 'ABC123D', falla: 'Sin tracción' },
//       origen: {
//         direccion: 'Av. Francisco de Miranda, Los Palos Grandes',
//         lat: 10.4961,
//         lng: -66.8480
//       },
//       destino: {
//         direccion: 'Taller Autofix, Zona Industrial La Urbina',
//         lat: 10.4820,
//         lng: -66.8150
//       }
//     });
//   };

//   return (
//     <div className="min-h-dvh bg-[var(--bg-main)] text-[var(--text-main)] flex flex-col justify-between font-sans antialiased pb-16 transition-colors">
//       <NetworkListener />
//       <Header />
//       <PermissionModal />

//       <main className="flex-1 flex flex-col justify-center items-center p-4 text-center max-w-md mx-auto w-full space-y-4">
//         {/* ESTADO IDLE */}
//         {estadoActual === ESTADOS_SERVICIO.IDLE && (
//           <div className="space-y-4 max-w-xs my-auto">
//             <div className="w-16 h-16 bg-[var(--bg-card)] border border-[var(--bg-card-border)] rounded-full flex items-center justify-center mx-auto text-[var(--color-primary)] shadow-inner">
//               <Truck className="w-8 h-8" />
//             </div>
//             <div>
//               <h2 className="font-bold text-lg">Esperando Asignación...</h2>
//               <p className="text-xs text-[var(--text-muted)] mt-1">
//                 Unidad disponible en zona. Se te notificará al recibir un servicio.
//               </p>
//             </div>
//             <button
//               onClick={simularLlegadaServicio}
//               className="w-full py-3 bg-[var(--color-primary)]/10 hover:bg-[var(--color-primary)]/20 text-[var(--color-primary)] font-bold text-xs rounded-xl border border-[var(--color-primary)]/30 transition-all active:scale-95"
//             >
//               [Simular Asignación de Servicio]
//             </button>
//           </div>
//         )}

//         {/* MAPA OPERATIVO EN VIVO */}
//         {servicioActivo && estadoActual !== ESTADOS_SERVICIO.IDLE && estadoActual !== 'EXITO_SERVICIO' && (
//           <MapComponent />
//         )}

//         {/* INFORME DE ÉXITO FINAL */}
//         <ServiceSuccess />
//       </main>

//       <AssignmentModal />
//       <ProgressStepper />
//       <EvidenceDropzone />
//       <BottomNav />
//     </div>
//   );
// }

// import { useEffect } from 'react';
// import { Header } from './components/layout/Header';
// import { NetworkListener } from './components/layout/NetworkListener';
// import { AssignmentModal } from './features/assignment/AssignmentModal';
// import { ProgressStepper } from './features/tracking/ProgressStepper';
// import { EvidenceDropzone } from './features/evidence/EvidenceDropzone';
// import { ServiceSuccess } from './features/evidence/ServiceSuccess';
// import { BottomNav } from './components/layout/BottomNav';
// import { MapComponent } from './components/ui/MapComponent';
// import { PermissionModal } from './components/permissions/PermissionModal';
// import { useServiceStore, ESTADOS_SERVICIO } from './store/useServiceStore';
// import { MapView, EarningsView, ProfileView } from './features/views/SecondaryViews';
// import { Truck } from 'lucide-react';

// export default function App() {
//   const cargarServicioPersistido = useServiceStore((state) => state.cargarServicioPersistido);
//   const asignarNuevoServicio = useServiceStore((state) => state.asignarNuevoServicio);
//   const estadoActual = useServiceStore((state) => state.estadoActual);
//   const servicioActivo = useServiceStore((state) => state.servicioActivo);
//   const tabActiva = useServiceStore((state) => state.tabActiva);

//   useEffect(() => {
//     cargarServicioPersistido();
//   }, [cargarServicioPersistido]);

//   const simularLlegadaServicio = () => {
//     asignarNuevoServicio({
//       id: '10928',
//       operador: 'Control Central',
//       cliente: { nombre: 'Carlos Mendoza', telefono: '04141234567' },
//       vehiculo: { marca: 'Toyota', modelo: 'Hilux', placa: 'ABC123D', falla: 'Sin tracción' },
//       origen: {
//         direccion: 'Av. Francisco de Miranda, Los Palos Grandes',
//         lat: 10.4961,
//         lng: -66.8480
//       },
//       destino: {
//         direccion: 'Taller Autofix, Zona Industrial La Urbina',
//         lat: 10.4820,
//         lng: -66.8150
//       }
//     });
//   };

//   return (
//     <div className="min-h-dvh bg-[var(--bg-main)] text-[var(--text-main)] flex flex-col justify-between font-sans antialiased pb-16 transition-colors">
//       <NetworkListener />
//       <Header />
//       <PermissionModal />

//       <main className="flex-1 flex flex-col justify-center items-center p-4 text-center max-w-md mx-auto w-full space-y-4">
        
//         {/* PESTAÑA PRINCIPAL: SERVICIOS */}
//         {tabActiva === 'jobs' && (
//           <>
//             {/* ESTADO IDLE (ESPERA) */}
//             {estadoActual === ESTADOS_SERVICIO.IDLE && (
//               <div className="space-y-4 max-w-xs my-auto">
//                 <div className="w-16 h-16 bg-[var(--bg-card)] border border-[var(--bg-card-border)] rounded-full flex items-center justify-center mx-auto text-[var(--color-primary)] shadow-inner">
//                   <Truck className="w-8 h-8" />
//                 </div>
//                 <div>
//                   <h2 className="font-bold text-lg">Esperando Asignación...</h2>
//                   <p className="text-xs text-[var(--text-muted)] mt-1">
//                     Unidad disponible en zona. Se te notificará al recibir un servicio.
//                   </p>
//                 </div>
//                 <button
//                   onClick={simularLlegadaServicio}
//                   className="w-full py-3 bg-[var(--color-primary)]/10 hover:bg-[var(--color-primary)]/20 text-[var(--color-primary)] font-bold text-xs rounded-xl border border-[var(--color-primary)]/30 transition-all active:scale-95 cursor-pointer"
//                 >
//                   [Simular Asignación de Servicio]
//                 </button>
//               </div>
//             )}

//             {/* MAPA OPERATIVO EN VIVO (Se oculta en estado PENDIENTE_EVIDENCIA) */}
//             {servicioActivo &&
//               estadoActual !== ESTADOS_SERVICIO.IDLE &&
//               estadoActual !== ESTADOS_SERVICIO.EXITO_SERVICIO &&
//               estadoActual !== ESTADOS_SERVICIO.PENDIENTE_EVIDENCIA && (
//                 <MapComponent />
//               )}

//             {/* CAPTURA DE EVIDENCIA Y DUAL FIRMAS */}
//             <EvidenceDropzone />

//             {/* INFORME DE ÉXITO FINAL */}
//             <ServiceSuccess />
//           </>
//         )}

//         {/* PESTAÑAS SECUNDARIAS */}
//         {tabActiva === 'map' && <MapView />}
//         {tabActiva === 'earnings' && <EarningsView />}
//         {tabActiva === 'profile' && <ProfileView />}

//       </main>

//       {/* COMPONENTES DE CONTROL Y NAVEGACIÓN */}
//       <AssignmentModal />
//       {tabActiva === 'jobs' && <ProgressStepper />}
//       <BottomNav />
//     </div>
//   );
// }

import { useEffect } from 'react';
import { Header } from './components/layout/Header';
import { NetworkListener } from './components/layout/NetworkListener';
import { AssignmentModal } from './features/assignment/AssignmentModal';
import { ProgressStepper } from './features/tracking/ProgressStepper';
import { EvidenceDropzone } from './features/evidence/EvidenceDropzone';
import { ServiceSuccess } from './features/evidence/ServiceSuccess';
import { BottomNav } from './components/layout/BottomNav';
import { MapComponent } from './components/ui/MapComponent';
import { PermissionModal } from './components/permissions/PermissionModal';
import { useServiceStore, ESTADOS_SERVICIO } from './store/useServiceStore';
import { MapView, EarningsView, ProfileView } from './features/views/SecondaryViews';
import { Truck } from 'lucide-react';

export default function App() {
  const cargarServicioPersistido = useServiceStore((state) => state.cargarServicioPersistido);
  const asignarNuevoServicio = useServiceStore((state) => state.asignarNuevoServicio);
  const estadoActual = useServiceStore((state) => state.estadoActual);
  const servicioActivo = useServiceStore((state) => state.servicioActivo);
  const tabActiva = useServiceStore((state) => state.tabActiva);

  useEffect(() => {
    cargarServicioPersistido();
  }, [cargarServicioPersistido]);

  const simularLlegadaServicio = () => {
    asignarNuevoServicio({
      id: '10928',
      operador: 'Control Central',
      cliente: { nombre: 'Luis Bermudez', telefono: '04129728222' },
      vehiculo: { marca: 'Toyota', modelo: 'Hilux', placa: 'ABC123D', falla: 'Sin tracción' },
      origen: {
        direccion: 'Av. Francisco de Miranda, Los Palos Grandes',
        lat: 10.4961,
        lng: -66.8480
      },
      destino: {
        direccion: 'Taller Autofix, Zona Industrial La Urbina',
        lat: 10.4820,
        lng: -66.8150
      }
    });
  };

  return (
    <div className="min-h-dvh bg-[var(--bg-main)] text-[var(--text-main)] flex flex-col justify-between font-sans antialiased pb-16 transition-colors">
      <NetworkListener />
      <Header />
      <PermissionModal />

      <main className="flex-1 flex flex-col justify-center items-center p-4 text-center max-w-md mx-auto w-full space-y-4">
        
        {/* PESTAÑA PRINCIPAL: SERVICIOS */}
        {tabActiva === 'jobs' && (
          <>
            {/* ESTADO IDLE (ESPERA) */}
            {estadoActual === ESTADOS_SERVICIO.IDLE && (
              <div className="space-y-4 max-w-xs my-auto">
                <div className="w-16 h-16 bg-[var(--bg-card)] border border-[var(--bg-card-border)] rounded-full flex items-center justify-center mx-auto text-[var(--color-primary)] shadow-inner">
                  <Truck className="w-8 h-8" />
                </div>
                <div>
                  <h2 className="font-bold text-lg">Esperando Asignación...</h2>
                  <p className="text-xs text-[var(--text-muted)] mt-1">
                    Unidad disponible en zona. Se te notificará al recibir un servicio.
                  </p>
                </div>
                <button
                  onClick={simularLlegadaServicio}
                  className="w-full py-3 bg-[var(--color-primary)]/10 hover:bg-[var(--color-primary)]/20 text-[var(--color-primary)] font-bold text-xs rounded-xl border border-[var(--color-primary)]/30 transition-all active:scale-95 cursor-pointer"
                >
                  [Simular Asignación de Servicio]
                </button>
              </div>
            )}

            {/* MAPA OPERATIVO EN VIVO (Se oculta en estado PENDIENTE_EVIDENCIA) */}
            {servicioActivo &&
              estadoActual !== ESTADOS_SERVICIO.IDLE &&
              estadoActual !== ESTADOS_SERVICIO.EXITO_SERVICIO &&
              estadoActual !== ESTADOS_SERVICIO.PENDIENTE_EVIDENCIA && (
                <MapComponent />
              )}

            {/* CAPTURA DE EVIDENCIA Y DUAL FIRMAS */}
            <EvidenceDropzone />

            {/* INFORME DE ÉXITO FINAL */}
            <ServiceSuccess />
          </>
        )}

        {/* PESTAÑAS SECUNDARIAS */}
        {tabActiva === 'map' && <MapView />}
        {tabActiva === 'earnings' && <EarningsView />}
        {tabActiva === 'profile' && <ProfileView />}

      </main>

      {/* COMPONENTES DE CONTROL Y NAVEGACIÓN */}
      <AssignmentModal />
      {tabActiva === 'jobs' && <ProgressStepper />}
      <BottomNav />
    </div>
  );
}