// import { MapPin, Car, Phone, AlertCircle, Check, X, Loader2 } from 'lucide-react';
// import { useState } from 'react';
// import { useServiceStore, ESTADOS_SERVICIO } from '../../store/useServiceStore';

// export function AssignmentModal() {
//   const estadoActual = useServiceStore((state) => state.estadoActual);
//   const servicioActivo = useServiceStore((state) => state.servicioActivo);
//   const aceptarServicioConOrigenGps = useServiceStore((state) => state.aceptarServicioConOrigenGps);
//   const cerrarServicio = useServiceStore((state) => state.cerrarServicio);

//   const [obteniendoGps, setObteniendoGps] = useState(false);

//   if (estadoActual !== ESTADOS_SERVICIO.PENDIENTE_ACEPTACION || !servicioActivo) {
//     return null;
//   }

//   const handleAceptar = () => {
//     setObteniendoGps(true);

//     if ('geolocation' in navigator) {
//       navigator.geolocation.getCurrentPosition(
//         (pos) => {
//           const lat = pos.coords.latitude;
//           const lng = pos.coords.longitude;

//           // Si hay conexión y Google Maps cargado, convertimos coordenadas a dirección legible
//           if (window.google && window.google.maps && navigator.onLine) {
//             const geocoder = new window.google.maps.Geocoder();
//             geocoder.geocode({ location: { lat, lng } }, (results, status) => {
//               const direccionCalle = (status === 'OK' && results[0])
//                 ? results[0].formatted_address
//                 : `Ubicación Gruero (${lat.toFixed(4)}, ${lng.toFixed(4)})`;

//               aceptarServicioConOrigenGps({
//                 direccion: `Mi Ubicación: ${direccionCalle}`,
//                 lat: lat,
//                 lng: lng
//               });
//               setObteniendoGps(false);
//             });
//           } else {
//             // Modo Offline: Guarda coordenadas exactas obtenidas del chip GPS
//             aceptarServicioConOrigenGps({
//               direccion: `Ubicación GPS Gruero (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
//               lat: lat,
//               lng: lng
//             });
//             setObteniendoGps(false);
//           }
//         },
//         (error) => {
//           console.warn('No se obtuvo GPS exacto, manteniendo datos por defecto:', error);
//           // Si el usuario rechaza permisos de GPS, mantiene el origen asignado
//           aceptarServicioConOrigenGps(servicioActivo.origen);
//           setObteniendoGps(false);
//         },
//         { enableHighAccuracy: true, timeout: 8000 }
//       );
//     } else {
//       aceptarServicioConOrigenGps(servicioActivo.origen);
//       setObteniendoGps(false);
//     }
//   };

//   const handleRechazar = () => {
//     cerrarServicio();
//   };

//   return (
//     <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
//       <div className="bg-[var(--bg-card)] text-[var(--text-main)] w-full max-w-md rounded-2xl border border-[var(--bg-card-border)] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-200">

//         {/* Banner Alerta */}
//         <div className="bg-[var(--color-primary)] text-slate-950 p-4 flex items-center justify-between font-black">
//           <div className="flex items-center gap-2 text-base uppercase tracking-wider">
//             <AlertCircle className="w-6 h-6 shrink-0" />
//             <span>¡NUEVA ASIGNACIÓN!</span>
//           </div>
//           <span className="text-xs bg-slate-950 text-white px-2.5 py-1 rounded-md">
//             #{servicioActivo.id}
//           </span>
//         </div>

//         <div className="p-4 space-y-3 max-h-[70vh] overflow-y-auto">

//           {/* Destino y Vehículo */}
//           <div className="bg-[var(--bg-main)] rounded-xl p-3.5 space-y-3 border border-[var(--bg-card-border)]">
//             <div className="flex items-start gap-3">
//               <MapPin className="w-5 h-5 text-[var(--color-tertiary)] shrink-0 mt-0.5" />
//               <div>
//                 <p className="text-[10px] font-bold text-[var(--text-muted)] tracking-wider">PUNTO DE RECOGIDA / DESTINO</p>
//                 <p className="text-sm font-semibold">{servicioActivo.destino?.direccion}</p>
//               </div>
//             </div>
//           </div>

//           <div className="bg-[var(--bg-main)] rounded-xl p-3.5 border border-[var(--bg-card-border)] space-y-2">
//             <div className="flex items-center gap-2 text-xs font-bold text-[var(--text-muted)] uppercase">
//               <Car className="w-4 h-4 text-[var(--color-primary)]" />
//               <span>Vehículo a Trasladar</span>
//             </div>
//             <div className="flex justify-between items-center text-sm">
//               <span className="font-bold">
//                 {servicioActivo.vehiculo?.marca} {servicioActivo.vehiculo?.modelo}
//               </span>
//               <span className="bg-[var(--color-primary)]/15 text-[var(--color-primary)] px-2 py-0.5 rounded font-mono font-bold text-xs border border-[var(--color-primary)]/30">
//                 {servicioActivo.vehiculo?.placa}
//               </span>
//             </div>
//             <p className="text-xs text-[var(--text-muted)] bg-[var(--bg-card)] p-2 rounded border border-[var(--bg-card-border)]">
//               <strong className="text-[var(--color-primary)]">Falla:</strong> {servicioActivo.vehiculo?.falla}
//             </p>
//           </div>

//           <div className="flex items-center justify-between bg-[var(--bg-main)] p-3 rounded-xl border border-[var(--bg-card-border)]">
//             <div>
//               <p className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Cliente</p>
//               <p className="text-sm font-bold">{servicioActivo.cliente?.nombre}</p>
//             </div>
//             <a
//               href={`tel:${servicioActivo.cliente?.telefono}`}
//               className="flex items-center gap-1.5 bg-[var(--bg-card)] text-[var(--text-main)] px-3 py-2 rounded-lg text-xs font-bold border border-[var(--bg-card-border)]"
//             >
//               <Phone className="w-3.5 h-3.5 text-[var(--color-tertiary)]" />
//               Llamar
//             </a>
//           </div>
//         </div>

//         {/* Acciones */}
//         <div className="p-4 bg-[var(--bg-main)] border-t border-[var(--bg-card-border)] grid grid-cols-2 gap-3">
//           <button
//             onClick={handleRechazar}
//             disabled={obteniendoGps}
//             className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm bg-[var(--bg-card)] text-rose-500 border border-[var(--bg-card-border)] active:scale-95 transition-all min-h-[48px]"
//           >
//             <X className="w-5 h-5" />
//             Rechazar
//           </button>

//           <button
//             onClick={handleAceptar}
//             disabled={obteniendoGps}
//             className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-black text-sm bg-[var(--color-tertiary)] text-slate-950 shadow-lg active:scale-95 transition-all min-h-[48px]"
//           >
//             {obteniendoGps ? (
//               <>
//                 <Loader2 className="w-5 h-5 animate-spin" />
//                 <span>GPS...</span>
//               </>
//             ) : (
//               <>
//                 <Check className="w-5 h-5 stroke-[3]" />
//                 <span>ACEPTAR</span>
//               </>
//             )}
//           </button>
//         </div>

//       </div>
//     </div>
//   );
// }

// import { MapPin, Car, Phone, AlertCircle, Check, X, Loader2 } from 'lucide-react';
// import { useState } from 'react';
// import { useServiceStore, ESTADOS_SERVICIO } from '../../store/useServiceStore';
// import { enviarSmsSeguimiento } from '../../utils/smsHelper';

// export function AssignmentModal() {
//   const estadoActual = useServiceStore((state) => state.estadoActual);
//   const servicioActivo = useServiceStore((state) => state.servicioActivo);
//   const aceptarServicioConGps = useServiceStore((state) => state.aceptarServicioConGps);
//   const cerrarServicio = useServiceStore((state) => state.cerrarServicio);

//   const [obteniendoGps, setObteniendoGps] = useState(false);

//   if (estadoActual !== ESTADOS_SERVICIO.PENDIENTE_ACEPTACION || !servicioActivo) {
//     return null;
//   }

//   const handleAceptar = () => {
//     setObteniendoGps(true);
//     aceptarServicioConGps({
//       direccion: 'Ubicación GPS Gruero',
//       lat: lat,
//       lng: lng
//     });
//     enviarSmsSeguimiento(servicioActivo.cliente?.telefono, servicioActivo.id, 15);

//     if ('geolocation' in navigator) {
//       navigator.geolocation.getCurrentPosition(
//         (pos) => {
//           const lat = pos.coords.latitude;
//           const lng = pos.coords.longitude;

//           // Guardamos el GPS del gruero en `ubicacionGruero` (Punto A) sin tocar `origen` (Punto B)
//           aceptarServicioConGps({
//             direccion: 'Ubicación GPS Gruero',
//             lat: lat,
//             lng: lng
//           });
//           setObteniendoGps(false);
//         },
//         (error) => {
//           console.warn('GPS no disponible o denegado:', error);
//           aceptarServicioConGps({
//             direccion: 'Ubicación Inicial Gruero',
//             lat: 10.4961,
//             lng: -66.8480
//           });
//           setObteniendoGps(false);
//         },
//         { enableHighAccuracy: true, timeout: 8000 }
//       );
//     } else {
//       aceptarServicioConGps({
//         direccion: 'Ubicación Inicial Gruero',
//         lat: 10.4961,
//         lng: -66.8480
//       });
//       setObteniendoGps(false);
//     }
//   };

//   const handleRechazar = () => {
//     cerrarServicio();
//   };

//   return (
//     <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
//       <div className="bg-[var(--bg-card)] text-[var(--text-main)] w-full max-w-md rounded-2xl border border-[var(--bg-card-border)] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-200">

//         {/* Banner Alerta */}
//         <div className="bg-[var(--color-primary)] text-slate-950 p-4 flex items-center justify-between font-black">
//           <div className="flex items-center gap-2 text-base uppercase tracking-wider">
//             <AlertCircle className="w-6 h-6 shrink-0" />
//             <span>¡NUEVA ASIGNACIÓN!</span>
//           </div>
//           <span className="text-xs bg-slate-950 text-white px-2.5 py-1 rounded-md">
//             #{servicioActivo.id}
//           </span>
//         </div>

//         <div className="p-4 space-y-3 max-h-[70vh] overflow-y-auto">

//           {/* Ruta Operativa: Punto B (Recogida) -> Punto C (Destino Final) */}
//           <div className="bg-[var(--bg-main)] rounded-xl p-3.5 space-y-3 border border-[var(--bg-card-border)] relative">
//             <div className="absolute left-[23px] top-[28px] bottom-[28px] w-0.5 bg-[var(--bg-card-border)] z-0" />

//             {/* Punto B: Recogida Cliente / Vehículo averiado */}
//             <div className="flex items-start gap-3 relative z-10">
//               <div className="bg-[var(--bg-main)] rounded-full p-0.5 shrink-0">
//                 <MapPin className="w-5 h-5 text-amber-500" />
//               </div>
//               <div>
//                 <p className="text-[10px] font-bold text-[var(--text-muted)] tracking-wider uppercase">
//                   PUNTO B (RECOGIDA / VEHÍCULO AVERIADO)
//                 </p>
//                 <p className="text-sm font-semibold">{servicioActivo.origen?.direccion}</p>
//               </div>
//             </div>

//             {/* Punto C: Destino Final del Traslado */}
//             <div className="flex items-start gap-3 relative z-10 pt-1">
//               <div className="bg-[var(--bg-main)] rounded-full p-0.5 shrink-0">
//                 <MapPin className="w-5 h-5 text-[var(--color-primary)]" />
//               </div>
//               <div>
//                 <p className="text-[10px] font-bold text-[var(--text-muted)] tracking-wider uppercase">
//                   PUNTO C (DESTINO DEL TRASLADO)
//                 </p>
//                 <p className="text-sm font-semibold">{servicioActivo.destino?.direccion}</p>
//               </div>
//             </div>
//           </div>

//           {/* Datos del Vehículo a Trasladar */}
//           <div className="bg-[var(--bg-main)] rounded-xl p-3.5 border border-[var(--bg-card-border)] space-y-2">
//             <div className="flex items-center gap-2 text-xs font-bold text-[var(--text-muted)] uppercase">
//               <Car className="w-4 h-4 text-[var(--color-primary)]" />
//               <span>Vehículo a Trasladar</span>
//             </div>
//             <div className="flex justify-between items-center text-sm">
//               <span className="font-bold">
//                 {servicioActivo.vehiculo?.marca} {servicioActivo.vehiculo?.modelo}
//               </span>
//               <span className="bg-[var(--color-primary)]/15 text-[var(--color-primary)] px-2 py-0.5 rounded font-mono font-bold text-xs border border-[var(--color-primary)]/30">
//                 {servicioActivo.vehiculo?.placa}
//               </span>
//             </div>
//             <p className="text-xs text-[var(--text-muted)] bg-[var(--bg-card)] p-2 rounded border border-[var(--bg-card-border)]">
//               <strong className="text-[var(--color-primary)]">Falla:</strong> {servicioActivo.vehiculo?.falla}
//             </p>
//           </div>

//           {/* Datos del Cliente */}
//           <div className="flex items-center justify-between bg-[var(--bg-main)] p-3 rounded-xl border border-[var(--bg-card-border)]">
//             <div>
//               <p className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Cliente</p>
//               <p className="text-sm font-bold">{servicioActivo.cliente?.nombre}</p>
//             </div>
//             <a
//               href={`tel:${servicioActivo.cliente?.telefono}`}
//               className="flex items-center gap-1.5 bg-[var(--bg-card)] text-[var(--text-main)] px-3 py-2 rounded-lg text-xs font-bold border border-[var(--bg-card-border)]"
//             >
//               <Phone className="w-3.5 h-3.5 text-[var(--color-tertiary)]" />
//               Llamar
//             </a>
//           </div>
//         </div>

//         {/* Acciones */}
//         <div className="p-4 bg-[var(--bg-main)] border-t border-[var(--bg-card-border)] grid grid-cols-2 gap-3">
//           <button
//             onClick={handleRechazar}
//             disabled={obteniendoGps}
//             className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm bg-[var(--bg-card)] text-rose-500 border border-[var(--bg-card-border)] active:scale-95 transition-all min-h-[48px]"
//           >
//             <X className="w-5 h-5" />
//             Rechazar
//           </button>

//           <button
//             onClick={handleAceptar}
//             disabled={obteniendoGps}
//             className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-black text-sm bg-[var(--color-tertiary)] text-slate-950 shadow-lg active:scale-95 transition-all min-h-[48px]"
//           >
//             {obteniendoGps ? (
//               <>
//                 <Loader2 className="w-5 h-5 animate-spin" />
//                 <span>GPS...</span>
//               </>
//             ) : (
//               <>
//                 <Check className="w-5 h-5 stroke-[3]" />
//                 <span>ACEPTAR</span>
//               </>
//             )}
//           </button>
//         </div>

//       </div>
//     </div>
//   );
// }  ULTIMA FUNCIONAL

// import { MapPin, Car, Phone, AlertCircle, Check, X, Loader2 } from 'lucide-react';
// import { useState } from 'react';
// import { useServiceStore, ESTADOS_SERVICIO } from '../../store/useServiceStore';
// import { enviarSmsSeguimiento } from '../../utils/smsHelper';

// export function AssignmentModal() {
//   const estadoActual = useServiceStore((state) => state.estadoActual);
//   const servicioActivo = useServiceStore((state) => state.servicioActivo);
//   const aceptarServicioConGps = useServiceStore((state) => state.aceptarServicioConGps);
//   const cerrarServicio = useServiceStore((state) => state.cerrarServicio);

//   const [obteniendoGps, setObteniendoGps] = useState(false);

//   if (estadoActual !== ESTADOS_SERVICIO.PENDIENTE_ACEPTACION || !servicioActivo) {
//     return null;
//   }

//   const handleAceptar = () => {
//     // 1. DISPARO SÍNCRONO INMEDIATO: Abre la app de SMS antes de perder el foco de clic
//     if (servicioActivo.cliente?.telefono) {
//       enviarSmsSeguimiento(servicioActivo.cliente.telefono, servicioActivo.id);
//     }

//     setObteniendoGps(true);

//     // 2. Temporizador de seguridad GPS
//     const timeoutSeguridad = setTimeout(() => {
//       aceptarServicioConGps({
//         direccion: 'Ubicación GPS Gruero',
//         lat: servicioActivo.origen?.lat || 10.4961,
//         lng: servicioActivo.origen?.lng || -66.8480
//       });
//       setObteniendoGps(false);
//     }, 2500);

//     if ('geolocation' in navigator) {
//       navigator.geolocation.getCurrentPosition(
//         (pos) => {
//           clearTimeout(timeoutSeguridad);
//           aceptarServicioConGps({
//             direccion: 'Ubicación GPS Gruero',
//             lat: pos.coords.latitude,
//             lng: pos.coords.longitude
//           });
//           setObteniendoGps(false);
//         },
//         (error) => {
//           clearTimeout(timeoutSeguridad);
//           aceptarServicioConGps({
//             direccion: 'Ubicación GPS Gruero',
//             lat: 10.4961,
//             lng: -66.8480
//           });
//           setObteniendoGps(false);
//         },
//         { enableHighAccuracy: false, timeout: 2000, maximumAge: 10000 }
//       );
//     } else {
//       clearTimeout(timeoutSeguridad);
//       aceptarServicioConGps({
//         direccion: 'Ubicación GPS Gruero',
//         lat: 10.4961,
//         lng: -66.8480
//       });
//       setObteniendoGps(false);
//     }
//   };

//   const handleRechazar = () => {
//     cerrarServicio();
//   };

//   return (
//     <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
//       <div className="bg-[var(--bg-card)] text-[var(--text-main)] w-full max-w-md rounded-2xl border border-[var(--bg-card-border)] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-200">
        
//         {/* Banner Alerta */}
//         <div className="bg-[var(--color-primary)] text-slate-950 p-4 flex items-center justify-between font-black">
//           <div className="flex items-center gap-2 text-base uppercase tracking-wider">
//             <AlertCircle className="w-6 h-6 shrink-0" />
//             <span>¡NUEVA ASIGNACIÓN!</span>
//           </div>
//           <span className="text-xs bg-slate-950 text-white px-2.5 py-1 rounded-md">
//             #{servicioActivo.id}
//           </span>
//         </div>

//         <div className="p-4 space-y-3 max-h-[70vh] overflow-y-auto">
          
//           {/* Ruta Operativa: Punto B -> Punto C */}
//           <div className="bg-[var(--bg-main)] rounded-xl p-3.5 space-y-3 border border-[var(--bg-card-border)] relative">
//             <div className="absolute left-[23px] top-[28px] bottom-[28px] w-0.5 bg-[var(--bg-card-border)] z-0" />

//             <div className="flex items-start gap-3 relative z-10">
//               <div className="bg-[var(--bg-main)] rounded-full p-0.5 shrink-0">
//                 <MapPin className="w-5 h-5 text-amber-500" />
//               </div>
//               <div>
//                 <p className="text-[10px] font-bold text-[var(--text-muted)] tracking-wider uppercase">
//                   PUNTO B (RECOGIDA / VEHÍCULO AVERIADO)
//                 </p>
//                 <p className="text-sm font-semibold">{servicioActivo.origen?.direccion}</p>
//               </div>
//             </div>

//             <div className="flex items-start gap-3 relative z-10 pt-1">
//               <div className="bg-[var(--bg-main)] rounded-full p-0.5 shrink-0">
//                 <MapPin className="w-5 h-5 text-[var(--color-primary)]" />
//               </div>
//               <div>
//                 <p className="text-[10px] font-bold text-[var(--text-muted)] tracking-wider uppercase">
//                   PUNTO C (DESTINO DEL TRASLADO)
//                 </p>
//                 <p className="text-sm font-semibold">{servicioActivo.destino?.direccion}</p>
//               </div>
//             </div>
//           </div>

//           {/* Vehículo */}
//           <div className="bg-[var(--bg-main)] rounded-xl p-3.5 border border-[var(--bg-card-border)] space-y-2">
//             <div className="flex items-center gap-2 text-xs font-bold text-[var(--text-muted)] uppercase">
//               <Car className="w-4 h-4 text-[var(--color-primary)]" />
//               <span>Vehículo a Trasladar</span>
//             </div>
//             <div className="flex justify-between items-center text-sm">
//               <span className="font-bold">
//                 {servicioActivo.vehiculo?.marca} {servicioActivo.vehiculo?.modelo}
//               </span>
//               <span className="bg-[var(--color-primary)]/15 text-[var(--color-primary)] px-2 py-0.5 rounded font-mono font-bold text-xs border border-[var(--color-primary)]/30">
//                 {servicioActivo.vehiculo?.placa}
//               </span>
//             </div>
//             <p className="text-xs text-[var(--text-muted)] bg-[var(--bg-card)] p-2 rounded border border-[var(--bg-card-border)]">
//               <strong className="text-[var(--color-primary)]">Falla:</strong> {servicioActivo.vehiculo?.falla}
//             </p>
//           </div>

//           {/* Cliente */}
//           <div className="flex items-center justify-between bg-[var(--bg-main)] p-3 rounded-xl border border-[var(--bg-card-border)]">
//             <div>
//               <p className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Cliente</p>
//               <p className="text-sm font-bold">{servicioActivo.cliente?.nombre}</p>
//             </div>
//             <a
//               href={`tel:${servicioActivo.cliente?.telefono}`}
//               className="flex items-center gap-1.5 bg-[var(--bg-card)] text-[var(--text-main)] px-3 py-2 rounded-lg text-xs font-bold border border-[var(--bg-card-border)]"
//             >
//               <Phone className="w-3.5 h-3.5 text-[var(--color-tertiary)]" />
//               Llamar
//             </a>
//           </div>
//         </div>

//         {/* Botones de Acción */}
//         <div className="p-4 bg-[var(--bg-main)] border-t border-[var(--bg-card-border)] grid grid-cols-2 gap-3">
//           <button
//             type="button"
//             onClick={handleRechazar}
//             disabled={obteniendoGps}
//             className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm bg-[var(--bg-card)] text-rose-500 border border-[var(--bg-card-border)] active:scale-95 transition-all min-h-[48px]"
//           >
//             <X className="w-5 h-5" />
//             Rechazar
//           </button>

//           <button
//             type="button"
//             onClick={handleAceptar}
//             disabled={obteniendoGps}
//             className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-black text-sm bg-[var(--color-tertiary)] text-slate-950 shadow-lg active:scale-95 transition-all min-h-[48px] cursor-pointer"
//           >
//             {obteniendoGps ? (
//               <>
//                 <Loader2 className="w-5 h-5 animate-spin" />
//                 <span>GPS...</span>
//               </>
//             ) : (
//               <>
//                 <Check className="w-5 h-5 stroke-[3]" />
//                 <span>ACEPTAR</span>
//               </>
//             )}
//           </button>
//         </div>

//       </div>
//     </div>
//   );
// }  CAMBIO POR PRUEBA

import { MapPin, Car, Phone, AlertCircle, Check, X, Loader2 } from 'lucide-react';
import { useState } from 'react';
import { useServiceStore, ESTADOS_SERVICIO } from '../../store/useServiceStore';
import { enviarSmsCliente } from '../../services/smsService';

export function AssignmentModal() {
  const estadoActual = useServiceStore((state) => state.estadoActual);
  const servicioActivo = useServiceStore((state) => state.servicioActivo);
  const aceptarServicioConGps = useServiceStore((state) => state.aceptarServicioConGps);
  const cerrarServicio = useServiceStore((state) => state.cerrarServicio);

  const [obteniendoGps, setObteniendoGps] = useState(false);

  if (estadoActual !== ESTADOS_SERVICIO.PENDIENTE_ACEPTACION || !servicioActivo) {
    return null;
  }

  const handleAceptar = () => {
    setObteniendoGps(true);

    // 1. DISPARO AUTOMÁTICO VÍA API DE FONDO (No frena la interfaz)
    // if (servicioActivo.cliente?.telefono) {
    //   enviarSmsCliente(servicioActivo.cliente.telefono, servicioActivo.id, 15);
    // }

    // 2. Temporizador de seguridad para capturar GPS e ingresar al mapa
    const timeoutSeguridad = setTimeout(() => {
      aceptarServicioConGps({
        direccion: 'Ubicación GPS Gruero',
        lat: servicioActivo.origen?.lat || 10.4961,
        lng: servicioActivo.origen?.lng || -66.8480
      });
      setObteniendoGps(false);
    }, 2000);

    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          clearTimeout(timeoutSeguridad);
          aceptarServicioConGps({
            direccion: 'Ubicación GPS Gruero',
            lat: pos.coords.latitude,
            lng: pos.coords.longitude
          });
          setObteniendoGps(false);
        },
        (error) => {
          clearTimeout(timeoutSeguridad);
          aceptarServicioConGps({
            direccion: 'Ubicación GPS Gruero',
            lat: 10.4961,
            lng: -66.8480
          });
          setObteniendoGps(false);
        },
        { enableHighAccuracy: false, timeout: 2000, maximumAge: 10000 }
      );
    } else {
      clearTimeout(timeoutSeguridad);
      aceptarServicioConGps({
        direccion: 'Ubicación GPS Gruero',
        lat: 10.4961,
        lng: -66.8480
      });
      setObteniendoGps(false);
    }
  };

  const handleRechazar = () => {
    cerrarServicio();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
      <div className="bg-[var(--bg-card)] text-[var(--text-main)] w-full max-w-md rounded-2xl border border-[var(--bg-card-border)] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-200">
        
        {/* Banner Alerta */}
        <div className="bg-[var(--color-primary)] text-slate-950 p-4 flex items-center justify-between font-black">
          <div className="flex items-center gap-2 text-base uppercase tracking-wider">
            <AlertCircle className="w-6 h-6 shrink-0" />
            <span>¡NUEVA ASIGNACIÓN!</span>
          </div>
          <span className="text-xs bg-slate-950 text-white px-2.5 py-1 rounded-md">
            #{servicioActivo.id}
          </span>
        </div>

        <div className="p-4 space-y-3 max-h-[70vh] overflow-y-auto">
          {/* Ruta Operativa */}
          <div className="bg-[var(--bg-main)] rounded-xl p-3.5 space-y-3 border border-[var(--bg-card-border)] relative">
            <div className="absolute left-[23px] top-[28px] bottom-[28px] w-0.5 bg-[var(--bg-card-border)] z-0" />

            <div className="flex items-start gap-3 relative z-10">
              <div className="bg-[var(--bg-main)] rounded-full p-0.5 shrink-0">
                <MapPin className="w-5 h-5 text-amber-500" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-[var(--text-muted)] tracking-wider uppercase">
                  PUNTO B (RECOGIDA / VEHÍCULO AVERIADO)
                </p>
                <p className="text-sm font-semibold">{servicioActivo.origen?.direccion}</p>
              </div>
            </div>

            <div className="flex items-start gap-3 relative z-10 pt-1">
              <div className="bg-[var(--bg-main)] rounded-full p-0.5 shrink-0">
                <MapPin className="w-5 h-5 text-[var(--color-primary)]" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-[var(--text-muted)] tracking-wider uppercase">
                  PUNTO C (DESTINO DEL TRASLADO)
                </p>
                <p className="text-sm font-semibold">{servicioActivo.destino?.direccion}</p>
              </div>
            </div>
          </div>

          {/* Vehículo */}
          <div className="bg-[var(--bg-main)] rounded-xl p-3.5 border border-[var(--bg-card-border)] space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-[var(--text-muted)] uppercase">
              <Car className="w-4 h-4 text-[var(--color-primary)]" />
              <span>Vehículo a Trasladar</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="font-bold">
                {servicioActivo.vehiculo?.marca} {servicioActivo.vehiculo?.modelo}
              </span>
              <span className="bg-[var(--color-primary)]/15 text-[var(--color-primary)] px-2 py-0.5 rounded font-mono font-bold text-xs border border-[var(--color-primary)]/30">
                {servicioActivo.vehiculo?.placa}
              </span>
            </div>
            <p className="text-xs text-[var(--text-muted)] bg-[var(--bg-card)] p-2 rounded border border-[var(--bg-card-border)]">
              <strong className="text-[var(--color-primary)]">Falla:</strong> {servicioActivo.vehiculo?.falla}
            </p>
          </div>

          {/* Cliente */}
          <div className="flex items-center justify-between bg-[var(--bg-main)] p-3 rounded-xl border border-[var(--bg-card-border)]">
            <div>
              <p className="text-[10px] text-[var(--text-muted)] font-bold uppercase">Cliente</p>
              <p className="text-sm font-bold">{servicioActivo.cliente?.nombre}</p>
            </div>
            <a
              href={`tel:${servicioActivo.cliente?.telefono}`}
              className="flex items-center gap-1.5 bg-[var(--bg-card)] text-[var(--text-main)] px-3 py-2 rounded-lg text-xs font-bold border border-[var(--bg-card-border)]"
            >
              <Phone className="w-3.5 h-3.5 text-[var(--color-tertiary)]" />
              Llamar
            </a>
          </div>
        </div>

        {/* Acciones */}
        <div className="p-4 bg-[var(--bg-main)] border-t border-[var(--bg-card-border)] grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={handleRechazar}
            disabled={obteniendoGps}
            className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm bg-[var(--bg-card)] text-rose-500 border border-[var(--bg-card-border)] active:scale-95 transition-all min-h-[48px]"
          >
            <X className="w-5 h-5" />
            Rechazar
          </button>

          <button
            type="button"
            onClick={handleAceptar}
            disabled={obteniendoGps}
            className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-black text-sm bg-[var(--color-tertiary)] text-slate-950 shadow-lg active:scale-95 transition-all min-h-[48px] cursor-pointer"
          >
            {obteniendoGps ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>GPS...</span>
              </>
            ) : (
              <>
                <Check className="w-5 h-5 stroke-[3]" />
                <span>ACEPTAR</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
}