import { MapPin, DollarSign, Award, Truck, ShieldCheck, Moon, RefreshCw } from 'lucide-react';
import { useServiceStore } from '../../store/useServiceStore';

// Vista de Mapa General / Cobertura
export function MapView() {
  return (
    <div className="w-full space-y-4 my-auto">
      <div className="bg-[var(--bg-card)] p-4 rounded-2xl border border-[var(--bg-card-border)] text-left space-y-2">
        <div className="flex items-center gap-2 text-[var(--color-primary)] font-bold text-xs uppercase">
          <MapPin className="w-4 h-4" />
          <span>Zona de Cobertura Activa</span>
        </div>
        <h3 className="font-bold text-base text-[var(--text-main)]">Caracas / Gran Caracas</h3>
        <p className="text-xs text-[var(--text-muted)]">
          Unidad rastreada vía GPS en tiempo real. Alta demanda proyectada en las próximas 2 horas.
        </p>
      </div>
    </div>
  );
}

// Vista de Ganancias y Resumen
export function EarningsView() {
  return (
    <div className="w-full space-y-3 my-auto">
      <div className="bg-[var(--bg-card)] p-5 rounded-2xl border border-[var(--bg-card-border)] text-center space-y-2 shadow-xl">
        <p className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider">Ganancias de Hoy</p>
        <h2 className="text-3xl font-black text-[var(--color-primary)]">$120.00</h2>
        <div className="flex justify-center gap-4 text-xs font-bold pt-2 border-t border-[var(--bg-card-border)] text-[var(--text-main)]">
          <span>3 Servicios</span>
          <span>•</span>
          <span>2.5 Horas Totales</span>
        </div>
      </div>
    </div>
  );
}

// Vista de Perfil y Grúa
export function ProfileView() {
  return (
    <div className="w-full space-y-3 text-left my-auto">
      <div className="bg-[var(--bg-card)] p-4 rounded-2xl border border-[var(--bg-card-border)] space-y-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-[var(--color-primary)]/15 text-[var(--color-primary)] rounded-full flex items-center justify-center font-black text-lg border border-[var(--color-primary)]/30">
            JP
          </div>
          <div>
            <h3 className="font-bold text-sm text-[var(--text-main)]">Juan Pérez</h3>
            <p className="text-xs text-[var(--text-muted)]">Chofer Operador Grúa #04</p>
          </div>
        </div>

        <div className="bg-[var(--bg-main)] p-3 rounded-xl border border-[var(--bg-card-border)] text-xs space-y-1.5">
          <div className="flex justify-between">
            <span className="text-[var(--text-muted)] font-bold">Unidad / Placa:</span>
            <span className="font-mono font-bold text-[var(--color-primary)]">A82BK9M</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[var(--text-muted)] font-bold">Tipo de Grúa:</span>
            <span>Plataforma Hidráulica</span>
          </div>
        </div>
      </div>
    </div>
  );
}