// import { CheckCircle2, Navigation, MapPin, Truck, Flag } from 'lucide-react';
// import { useServiceStore, ESTADOS_SERVICIO } from '../../store/useServiceStore';

// const PASOS = [
//   { key: ESTADOS_SERVICIO.ACEPTADO, label: 'Aceptado', icon: CheckCircle2 },
//   { key: ESTADOS_SERVICIO.EN_RUTA_ORIGEN, label: 'Ruta A', icon: Navigation },
//   { key: ESTADOS_SERVICIO.EN_PUNTO_ORIGEN, label: 'Punto A', icon: MapPin },
//   { key: ESTADOS_SERVICIO.EN_RUTA_DESTINO, label: 'Ruta B', icon: Truck },
//   { key: ESTADOS_SERVICIO.ENTREGADO, label: 'Entregado', icon: Flag }
// ];

// export function ProgressStepper() {
//   const estadoActual = useServiceStore((state) => state.estadoActual);
//   const avanzarEstado = useServiceStore((state) => state.avanzarEstado);
//   const servicioActivo = useServiceStore((state) => state.servicioActivo);

//   if (!servicioActivo || estadoActual === ESTADOS_SERVICIO.IDLE || estadoActual === ESTADOS_SERVICIO.PENDIENTE_ACEPTACION || estadoActual === 'EXITO_SERVICIO') {
//     return null;
//   }

//   const indiceActual = PASOS.findIndex((s) => s.key === estadoActual);

//   const getBotonConfig = () => {
//     switch (estadoActual) {
//       case ESTADOS_SERVICIO.ACEPTADO:
//         return {
//           texto: 'INICIAR RUTA A ORIGEN (PUNTO A)',
//           siguienteEstado: ESTADOS_SERVICIO.EN_RUTA_ORIGEN,
//           color: 'bg-[var(--color-primary)] text-slate-950'
//         };
//       case ESTADOS_SERVICIO.EN_RUTA_ORIGEN:
//         return {
//           texto: 'MARCAR LLEGADA A ORIGEN',
//           siguienteEstado: ESTADOS_SERVICIO.EN_PUNTO_ORIGEN,
//           color: 'bg-[var(--color-tertiary)] text-slate-950'
//         };
//       case ESTADOS_SERVICIO.EN_PUNTO_ORIGEN:
//         return {
//           texto: 'ENGANCHE LISTO ➔ INICIAR TRASLADO',
//           siguienteEstado: ESTADOS_SERVICIO.EN_RUTA_DESTINO,
//           color: 'bg-[var(--color-primary)] text-slate-950'
//         };
//       case ESTADOS_SERVICIO.EN_RUTA_DESTINO:
//         return {
//           texto: 'MARCAR ENTREGADO EN DESTINO (PUNTO B)',
//           siguienteEstado: ESTADOS_SERVICIO.ENTREGADO,
//           color: 'bg-[var(--color-tertiary)] text-slate-950'
//         };
//       default:
//         return null;
//     }
//   };

//   const configBoton = getBotonConfig();

//   const handleSiguientePaso = () => {
//     if (!configBoton) return;
//     if ('geolocation' in navigator) {
//       navigator.geolocation.getCurrentPosition(
//         (pos) => {
//           avanzarEstado(configBoton.siguienteEstado, {
//             lat: pos.coords.latitude,
//             lng: pos.coords.longitude
//           });
//         },
//         () => avanzarEstado(configBoton.siguienteEstado)
//       );
//     } else {
//       avanzarEstado(configBoton.siguienteEstado);
//     }
//   };

//   return (
//     <div className="bg-[var(--bg-card)] border-t border-[var(--bg-card-border)] p-4 space-y-4 transition-colors">
//       <div className="flex items-center justify-between relative max-w-md mx-auto px-2">
//         <div className="absolute top-1/2 left-6 right-6 -translate-y-1/2 h-1 bg-[var(--bg-card-border)] -z-0" />
//         <div
//           className="absolute top-1/2 left-6 h-1 bg-[var(--color-primary)] -z-0 transition-all duration-300"
//           style={{
//             width: `${Math.max(0, (indiceActual / (PASOS.length - 1)) * 100)}%`
//           }}
//         />

//         {PASOS.map((paso, idx) => {
//           const completado = idx < indiceActual;
//           const esActual = idx === indiceActual;
//           const Icono = paso.icon;

//           return (
//             <div key={paso.key} className="flex flex-col items-center gap-1 z-10">
//               <div
//                 className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs transition-all ${
//                   completado
//                     ? 'bg-[var(--color-primary)] text-slate-950 ring-4 ring-[var(--bg-card)]'
//                     : esActual
//                     ? 'bg-[var(--color-tertiary)] text-slate-950 ring-4 ring-[var(--bg-card)] animate-pulse'
//                     : 'bg-[var(--bg-main)] text-[var(--text-muted)] border border-[var(--bg-card-border)]'
//                 }`}
//               >
//                 <Icono className="w-4 h-4 stroke-[2.5]" />
//               </div>
//               <span
//                 className={`text-[10px] font-bold ${
//                   esActual ? 'text-[var(--color-tertiary)]' : completado ? 'text-[var(--color-primary)]' : 'text-[var(--text-muted)]'
//                 }`}
//               >
//                 {paso.label}
//               </span>
//             </div>
//           );
//         })}
//       </div>

//       {configBoton && (
//         <div className="max-w-md mx-auto pt-1">
//           <button
//             onClick={handleSiguientePaso}
//             className={`w-full py-4 px-4 rounded-xl font-black text-sm uppercase tracking-wide shadow-xl active:scale-95 transition-all min-h-[52px] flex items-center justify-center gap-2 ${configBoton.color}`}
//           >
//             <span>{configBoton.texto}</span>
//           </button>
//         </div>
//       )}
//     </div>
//   );
// }

import { Check, Navigation, MapPin, Flag, ArrowRight } from 'lucide-react';
import { useServiceStore, ESTADOS_SERVICIO } from '../../store/useServiceStore';

export function ProgressStepper() {
  const estadoActual = useServiceStore((state) => state.estadoActual);
  const servicioActivo = useServiceStore((state) => state.servicioActivo);
  const avanzarEstado = useServiceStore((state) => state.avanzarEstado);

  if (
    !servicioActivo ||
    estadoActual === ESTADOS_SERVICIO.IDLE ||
    estadoActual === ESTADOS_SERVICIO.EXITO_SERVICIO ||
    estadoActual === ESTADOS_SERVICIO.PENDIENTE_EVIDENCIA
  ) {
    return null;
  }

  // Pasos de la operación (A, B y C)
  const pasillos = [
    { id: ESTADOS_SERVICIO.ACEPTADO, label: 'Aceptado', icon: Check },
    { id: ESTADOS_SERVICIO.EN_CAMINO_ORIGEN, label: 'Ruta B', icon: Navigation },
    { id: ESTADOS_SERVICIO.EN_SITIO_ORIGEN, label: 'Punto B', icon: MapPin },
    { id: ESTADOS_SERVICIO.EN_CAMINO_DESTINO, label: 'Ruta C', icon: Navigation },
    { id: ESTADOS_SERVICIO.PENDIENTE_EVIDENCIA, label: 'Punto C', icon: Flag },
  ];

  const obtenerIndiceEstado = (estado) => {
    switch (estado) {
      case ESTADOS_SERVICIO.ACEPTADO: return 0;
      case ESTADOS_SERVICIO.EN_CAMINO_ORIGEN: return 1;
      case ESTADOS_SERVICIO.EN_SITIO_ORIGEN: return 2;
      case ESTADOS_SERVICIO.EN_CAMINO_DESTINO: return 3;
      case ESTADOS_SERVICIO.PENDIENTE_EVIDENCIA: return 4;
      default: return 0;
    }
  };

  const indiceActual = obtenerIndiceEstado(estadoActual);

  // Configuración dinámica del botón
  const obtenerBotonConfig = () => {
    switch (estadoActual) {
      case ESTADOS_SERVICIO.ACEPTADO:
        return {
          texto: 'INICIAR RUTA A RECOGIDA (PUNTO B)',
          siguienteEstado: ESTADOS_SERVICIO.EN_CAMINO_ORIGEN,
          color: 'bg-[var(--color-primary)] text-slate-950 shadow-[var(--color-primary)]/20'
        };
      case ESTADOS_SERVICIO.EN_CAMINO_ORIGEN:
        return {
          texto: 'LLEGUÉ A PUNTO B (VEHÍCULO ENCONTRADO)',
          siguienteEstado: ESTADOS_SERVICIO.EN_SITIO_ORIGEN,
          color: 'bg-amber-500 text-slate-950 shadow-amber-500/20'
        };
      case ESTADOS_SERVICIO.EN_SITIO_ORIGEN:
        return {
          texto: 'INICIAR TRASLADO A DESTINO (PUNTO C)',
          siguienteEstado: ESTADOS_SERVICIO.EN_CAMINO_DESTINO,
          color: 'bg-[var(--color-primary)] text-slate-950 shadow-[var(--color-primary)]/20'
        };
      case ESTADOS_SERVICIO.EN_CAMINO_DESTINO:
        return {
          texto: 'LLEGUÉ A DESTINO FINAL (PUNTO C)',
          siguienteEstado: ESTADOS_SERVICIO.PENDIENTE_EVIDENCIA,
          color: 'bg-emerald-500 text-slate-950 shadow-emerald-500/20'
        };
      default:
        return null;
    }
  };

  const botonConfig = obtenerBotonConfig();

  const handleSiguiente = () => {
    if (botonConfig) {
      avanzarEstado(botonConfig.siguienteEstado);
    }
  };

  return (
    <div className="fixed bottom-16 left-0 right-0 z-30 bg-[var(--bg-card)]/95 backdrop-blur-md border-t border-[var(--bg-card-border)] p-3 space-y-3 max-w-md mx-auto shadow-2xl">
      
      {/* Indicadores de Pasos */}
      <div className="flex items-center justify-between px-2">
        {pasillos.map((paso, idx) => {
          const Icon = paso.icon;
          const estaCompletado = idx < indiceActual;
          const esActual = idx === indiceActual;

          return (
            <div key={paso.id} className="flex flex-col items-center flex-1 relative">
              {idx > 0 && (
                <div
                  className={`absolute top-3.5 -left-1/2 w-full h-0.5 transition-colors -z-10 ${
                    idx <= indiceActual ? 'bg-[var(--color-primary)]' : 'bg-[var(--bg-card-border)]'
                  }`}
                />
              )}

              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all shadow-md ${
                  estaCompletado
                    ? 'bg-[var(--color-primary)] text-slate-950'
                    : esActual
                    ? 'bg-[var(--color-primary)] text-slate-950 ring-4 ring-[var(--color-primary)]/20 scale-110'
                    : 'bg-[var(--bg-main)] text-[var(--text-muted)] border border-[var(--bg-card-border)]'
                }`}
              >
                <Icon className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>

              <span
                className={`text-[9px] mt-1 font-bold truncate max-w-[55px] ${
                  esActual ? 'text-[var(--color-primary)]' : 'text-[var(--text-muted)]'
                }`}
              >
                {paso.label}
              </span>
            </div>
          );
        })}
      </div>

      {/* Botón de Acción Principal */}
      {botonConfig && (
        <button
          onClick={handleSiguiente}
          className={`w-full py-3.5 font-black text-xs uppercase tracking-wider rounded-xl shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 min-h-[48px] ${botonConfig.color}`}
        >
          <span>{botonConfig.texto}</span>
          <ArrowRight className="w-4 h-4 stroke-[3]" />
        </button>
      )}

    </div>
  );
}