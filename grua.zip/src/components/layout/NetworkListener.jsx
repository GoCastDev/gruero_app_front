// import { useEffect } from 'react';
// import { useServiceStore } from '../../store/useServiceStore';

// export function NetworkListener() {
//   const setOnlineStatus = useServiceStore((state) => state.setOnlineStatus);

//   useEffect(() => {
//     const handleOnline = () => setOnlineStatus(true);
//     const handleOffline = () => setOnlineStatus(false);

//     window.addEventListener('online', handleOnline);
//     window.addEventListener('offline', handleOffline);

//     return () => {
//       window.removeEventListener('online', handleOnline);
//       window.removeEventListener('offline', handleOffline);
//     };
//   }, [setOnlineStatus]);

//   return null; // Componente sin interfaz, solo lógica
// }

import { useEffect } from 'react';
import { useServiceStore } from '../../store/useServiceStore';

export function NetworkListener() {
  const setIsOnline = useServiceStore((state) => state.setIsOnline);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [setIsOnline]);

  return null;
}