// import { Briefcase, Map, Wallet, User } from 'lucide-react';

// export function BottomNav() {
//   return (
//     <nav className="fixed bottom-0 left-0 right-0 bg-[var(--bg-card)] border-t border-[var(--bg-card-border)] py-2 px-4 z-30 transition-colors">
//       <div className="max-w-md mx-auto grid grid-cols-4 gap-1">
        
//         {/* Tab Activa */}
//         <button className="flex flex-col items-center justify-center py-1.5 px-2 bg-[var(--color-primary)] text-slate-950 rounded-xl font-black transition-all">
//           <Briefcase className="w-4 h-4" />
//           <span className="text-[10px] mt-0.5 tracking-wider">Jobs</span>
//         </button>

//         <button className="flex flex-col items-center justify-center py-1.5 px-2 text-[var(--text-muted)] hover:text-[var(--text-main)] transition-all">
//           <Map className="w-4 h-4" />
//           <span className="text-[10px] mt-0.5">Map</span>
//         </button>

//         <button className="flex flex-col items-center justify-center py-1.5 px-2 text-[var(--text-muted)] hover:text-[var(--text-main)] transition-all">
//           <Wallet className="w-4 h-4" />
//           <span className="text-[10px] mt-0.5">Earnings</span>
//         </button>

//         <button className="flex flex-col items-center justify-center py-1.5 px-2 text-[var(--text-muted)] hover:text-[var(--text-main)] transition-all">
//           <User className="w-4 h-4" />
//           <span className="text-[10px] mt-0.5">Profile</span>
//         </button>

//       </div>
//     </nav>
//   );
// }

import { Truck, Map, Wallet, User } from 'lucide-react';
import { useServiceStore } from '../../store/useServiceStore';

export function BottomNav() {
  const tabActiva = useServiceStore((state) => state.tabActiva);
  const setTabActiva = useServiceStore((state) => state.setTabActiva);

  const botones = [
    { id: 'jobs', label: 'Servicios', icon: Truck },
    { id: 'map', label: 'Mapa', icon: Map },
    { id: 'earnings', label: 'Ganancias', icon: Wallet },
    { id: 'profile', label: 'Perfil', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[var(--bg-card)] border-t border-[var(--bg-card-border)] py-2 px-4 max-w-md mx-auto shadow-2xl transition-colors">
      <div className="flex justify-around items-center">
        {botones.map((item) => {
          const Icon = item.icon;
          const esActivo = tabActiva === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setTabActiva(item.id)}
              className={`flex flex-col items-center justify-center w-16 py-1 rounded-xl transition-all active:scale-95 ${
                esActivo
                  ? 'text-slate-950 bg-[var(--color-primary)] font-black shadow-lg shadow-[var(--color-primary)]/20'
                  : 'text-[var(--text-muted)] hover:text-[var(--text-main)] font-medium'
              }`}
            >
              <Icon className={`w-5 h-5 ${esActivo ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              <span className="text-[10px] mt-0.5 tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}