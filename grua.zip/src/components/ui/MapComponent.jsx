// import { useState } from 'react';
// import { MapPin, Navigation, WifiOff, Maximize2, Minimize2 } from 'lucide-react';
// import { useServiceStore, ESTADOS_SERVICIO } from '../../store/useServiceStore';

// export function MapComponent() {
//   const [isExpanded, setIsExpanded] = useState(false);
//   const isOnline = useServiceStore((state) => state.isOnline);
//   const servicioActivo = useServiceStore((state) => state.servicioActivo);
//   const estadoActual = useServiceStore((state) => state.estadoActual);

//   if (!servicioActivo) return null;

//   const grueroObj = servicioActivo.ubicacionGruero; // Punto A
//   const origenObj = servicioActivo.origen;           // Punto B
//   const destinoObj = servicioActivo.destino;         // Punto C

//   // Formatear parámetros con Coordenadas Lat/Lng (o dirección de texto como fallback)
//   const puntoAParam = (grueroObj?.lat && grueroObj?.lng)
//     ? `${grueroObj.lat},${grueroObj.lng}`
//     : encodeURIComponent(grueroObj?.direccion || 'Mi Ubicacion');

//   const puntoBParam = (origenObj?.lat && origenObj?.lng)
//     ? `${origenObj.lat},${origenObj.lng}`
//     : encodeURIComponent(origenObj?.direccion || 'Punto de Recogida');

//   const puntoCParam = (destinoObj?.lat && destinoObj?.lng)
//     ? `${destinoObj.lat},${destinoObj.lng}`
//     : encodeURIComponent(destinoObj?.direccion || 'Destino Final');

//   // LÓGICA DINÁMICA DE RUTA (Google Embed exige máximo 2 puntos por tramo)
//   // Tramo 1: Gruero en camino a buscar el carro (A -> B)
//   // Tramo 2: Carro enganchado en camino al taller (B -> C)
//   const esTramoRecogida = 
//     estadoActual === ESTADOS_SERVICIO.ACEPTADO || 
//     estadoActual === ESTADOS_SERVICIO.EN_CAMINO_ORIGEN || 
//     estadoActual === ESTADOS_SERVICIO.EN_SITIO_ORIGEN;

//   const origenIframe = esTramoRecogida ? puntoAParam : puntoBParam;
//   const destinoIframe = esTramoRecogida ? puntoBParam : puntoCParam;

//   // Sintaxis saddr/daddr para forzar el dibujo de la línea azul en el iframe
//   const mapEmbedUrl = `https://maps.google.com/maps?saddr=${origenIframe}&daddr=${destinoIframe}&output=embed`;

//   // Navegación Externa en Google Maps App (Mantiene los 3 puntos A -> B -> C)
//   const gpsNavigationUrl = `https://www.google.com/maps/dir/?api=1&origin=${puntoAParam}&destination=${puntoCParam}&waypoints=${puntoBParam}&travelmode=driving`;

//   const toggleExpand = () => setIsExpanded(!isExpanded);

//   if (!isOnline) {
//     return (
//       <div className="w-full h-72 bg-[var(--bg-card)] border border-[var(--bg-card-border)] rounded-2xl flex flex-col items-center justify-center p-6 text-center space-y-3 transition-colors">
//         <div className="w-12 h-12 bg-amber-500/10 text-[var(--color-primary)] rounded-full flex items-center justify-center">
//           <WifiOff className="w-6 h-6" />
//         </div>
//         <div>
//           <h4 className="font-bold text-sm text-[var(--text-main)]">Mapa no disponible offline</h4>
//           <p className="text-xs text-[var(--text-muted)] mt-0.5">
//             Mostrando detalles de ruta guardados en el teléfono.
//           </p>
//         </div>
//         <div className="w-full bg-[var(--bg-main)] p-3 rounded-xl border border-[var(--bg-card-border)] text-left text-xs space-y-2">
//           <div className="flex items-center gap-2">
//             <MapPin className="w-4 h-4 text-emerald-500 shrink-0" />
//             <span className="truncate"><strong>Punto A (Gruero):</strong> {grueroObj?.direccion || 'Ubicación GPS'}</span>
//           </div>
//           <div className="flex items-center gap-2">
//             <MapPin className="w-4 h-4 text-amber-500 shrink-0" />
//             <span className="truncate"><strong>Punto B (Recogida):</strong> {origenObj?.direccion || 'Vehículo Cliente'}</span>
//           </div>
//           <div className="flex items-center gap-2">
//             <MapPin className="w-4 h-4 text-[var(--color-primary)] shrink-0" />
//             <span className="truncate"><strong>Punto C (Destino):</strong> {destinoObj?.direccion || 'Taller / Entrega'}</span>
//           </div>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <>
//       <div className="w-full space-y-3">
//         <div
//           className={`relative rounded-2xl overflow-hidden border border-[var(--bg-card-border)] shadow-2xl bg-[var(--bg-card)] transition-all duration-300 ${
//             isExpanded
//               ? 'fixed inset-3 z-50 flex flex-col h-[calc(100dvh-24px)] max-w-lg mx-auto'
//               : 'w-full h-80 sm:h-[420px]'
//           }`}
//         >
//           {/* Header Superior Flotante */}
//           <div className="absolute top-3 left-3 right-3 z-20 flex items-center justify-between gap-2 pointer-events-none">
//             <div className="bg-[var(--bg-card)]/90 backdrop-blur-md p-2.5 rounded-xl border border-[var(--bg-card-border)] text-left text-[11px] space-y-1 shadow-lg flex-1 min-w-0">
//               <div className="flex items-center gap-2 truncate">
//                 <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
//                 <span className="truncate font-semibold text-[var(--text-main)]">
//                   <strong>Punto A (Gruero):</strong> {grueroObj?.direccion || 'GPS Actual'}
//                 </span>
//               </div>
//               <div className="flex items-center gap-2 truncate">
//                 <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
//                 <span className="truncate font-semibold text-[var(--text-main)]">
//                   <strong>Punto B (Recogida):</strong> {origenObj?.direccion || 'Vehículo Cliente'}
//                 </span>
//               </div>
//               <div className="flex items-center gap-2 truncate">
//                 <span className="w-2 h-2 rounded-full bg-[var(--color-primary)] shrink-0" />
//                 <span className="truncate font-semibold text-[var(--text-main)]">
//                   <strong>Punto C (Destino):</strong> {destinoObj?.direccion || 'Taller / Entrega'}
//                 </span>
//               </div>
//             </div>

//             <button
//               type="button"
//               onClick={toggleExpand}
//               className="pointer-events-auto bg-[var(--bg-card)] hover:bg-[var(--bg-main)] text-[var(--text-main)] p-3 rounded-xl border border-[var(--bg-card-border)] shadow-lg active:scale-90 transition-all shrink-0 flex items-center justify-center"
//               title={isExpanded ? 'Reducir Mapa' : 'Ampliar Mapa'}
//             >
//               {isExpanded ? (
//                 <Minimize2 className="w-5 h-5 text-[var(--color-primary)]" />
//               ) : (
//                 <Maximize2 className="w-5 h-5 text-[var(--color-primary)]" />
//               )}
//             </button>
//           </div>

//           <iframe
//             title="Mapa de Ruta de Servicio"
//             width="100%"
//             height="100%"
//             className="w-full h-full border-0 grayscale-[15%] contrast-[105%]"
//             loading="lazy"
//             allowFullScreen
//             src={mapEmbedUrl}
//           />

//           {isExpanded && (
//             <div className="absolute bottom-4 left-4 right-4 z-20">
//               <button
//                 type="button"
//                 onClick={toggleExpand}
//                 className="w-full py-3.5 bg-[var(--bg-card)] border border-[var(--bg-card-border)] text-[var(--text-main)] font-bold text-xs uppercase rounded-xl shadow-xl active:scale-95 transition-all"
//               >
//                 Volver a la Vista Operativa
//               </button>
//             </div>
//           )}
//         </div>

//         {!isExpanded && (
//           <a
//             href={gpsNavigationUrl}
//             target="_blank"
//             rel="noopener noreferrer"
//             className="w-full py-3.5 bg-[var(--color-primary)] hover:opacity-90 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
//           >
//             <Navigation className="w-4 h-4 fill-current" />
//             <span>RUTA GPS (A ➔ B ➔ C)</span>
//           </a>
//         )}
//       </div>

//       {isExpanded && (
//         <div
//           onClick={toggleExpand}
//           className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 animate-in fade-in duration-200"
//         />
//       )}
//     </>
//   );
// }

import { useState } from 'react';
import { MapPin, Navigation, WifiOff, Maximize2, Minimize2 } from 'lucide-react';
import { useServiceStore, ESTADOS_SERVICIO } from '../../store/useServiceStore';

export function MapComponent() {
  const [isExpanded, setIsExpanded] = useState(false);
  const isOnline = useServiceStore((state) => state.isOnline);
  const servicioActivo = useServiceStore((state) => state.servicioActivo);
  const estadoActual = useServiceStore((state) => state.estadoActual);

  if (!servicioActivo) return null;

  const grueroObj = servicioActivo.ubicacionGruero; // Punto A
  const origenObj = servicioActivo.origen;           // Punto B
  const destinoObj = servicioActivo.destino;         // Punto C

  // Formatear coordenadas o texto seguro para la URL
  const puntoAParam = (grueroObj?.lat && grueroObj?.lng)
    ? `${grueroObj.lat},${grueroObj.lng}`
    : encodeURIComponent(grueroObj?.direccion || 'Caracas, Venezuela');

  const puntoBParam = (origenObj?.lat && origenObj?.lng)
    ? `${origenObj.lat},${origenObj.lng}`
    : encodeURIComponent(origenObj?.direccion || 'Los Palos Grandes, Caracas');

  const puntoCParam = (destinoObj?.lat && destinoObj?.lng)
    ? `${destinoObj.lat},${destinoObj.lng}`
    : encodeURIComponent(destinoObj?.direccion || 'La Urbina, Caracas');

  // Determinar tramo dinámico según la etapa operativa
  const esTramoRecogida = 
    estadoActual === ESTADOS_SERVICIO.ACEPTADO || 
    estadoActual === ESTADOS_SERVICIO.EN_CAMINO_ORIGEN || 
    estadoActual === ESTADOS_SERVICIO.EN_SITIO_ORIGEN;

  const origenIframe = esTramoRecogida ? puntoAParam : puntoBParam;
  const destinoIframe = esTramoRecogida ? puntoBParam : puntoCParam;

  // URL 100% compatible con iFrames móviles de Google Maps
  const mapEmbedUrl = `https://maps.google.com/maps?q=${origenIframe}%20to%20${destinoIframe}&t=&z=13&ie=UTF8&iwloc=&output=embed`;

  // URL para la App externa de Google Maps (3 Puntos A -> B -> C)
  const gpsNavigationUrl = `https://www.google.com/maps/dir/?api=1&origin=${puntoAParam}&destination=${puntoCParam}&waypoints=${puntoBParam}&travelmode=driving`;

  const toggleExpand = () => setIsExpanded(!isExpanded);

  if (!isOnline) {
    return (
      <div className="w-full h-72 bg-[var(--bg-card)] border border-[var(--bg-card-border)] rounded-2xl flex flex-col items-center justify-center p-6 text-center space-y-3 transition-colors">
        <div className="w-12 h-12 bg-amber-500/10 text-[var(--color-primary)] rounded-full flex items-center justify-center">
          <WifiOff className="w-6 h-6" />
        </div>
        <div>
          <h4 className="font-bold text-sm text-[var(--text-main)]">Mapa no disponible offline</h4>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            Mostrando detalles de ruta guardados en el teléfono.
          </p>
        </div>
        <div className="w-full bg-[var(--bg-main)] p-3 rounded-xl border border-[var(--bg-card-border)] text-left text-xs space-y-2">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-500 shrink-0" />
            <span className="truncate"><strong>Punto A (Gruero):</strong> {grueroObj?.direccion || 'GPS Actual'}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-amber-500 shrink-0" />
            <span className="truncate"><strong>Punto B (Recogida):</strong> {origenObj?.direccion || 'Vehículo Cliente'}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[var(--color-primary)] shrink-0" />
            <span className="truncate"><strong>Punto C (Destino):</strong> {destinoObj?.direccion || 'Taller / Entrega'}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Contenedor principal con margen inferior para evitar solapamientos */}
      <div className="w-full space-y-3 pb-28">
        <div
          className={`relative rounded-2xl overflow-hidden border border-[var(--bg-card-border)] shadow-2xl bg-[var(--bg-card)] transition-all duration-300 ${
            isExpanded
              ? 'fixed inset-3 z-50 flex flex-col h-[calc(100dvh-24px)] max-w-lg mx-auto'
              : 'w-full h-80 sm:h-[420px]'
          }`}
        >
          {/* Header Superior Flotante */}
          <div className="absolute top-3 left-3 right-3 z-20 flex items-center justify-between gap-2 pointer-events-none">
            <div className="bg-[var(--bg-card)]/90 backdrop-blur-md p-2.5 rounded-xl border border-[var(--bg-card-border)] text-left text-[11px] space-y-1 shadow-lg flex-1 min-w-0">
              <div className="flex items-center gap-2 truncate">
                <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                <span className="truncate font-semibold text-[var(--text-main)]">
                  <strong>Punto A (Gruero):</strong> {grueroObj?.direccion || 'GPS Actual'}
                </span>
              </div>
              <div className="flex items-center gap-2 truncate">
                <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                <span className="truncate font-semibold text-[var(--text-main)]">
                  <strong>Punto B (Recogida):</strong> {origenObj?.direccion || 'Vehículo Cliente'}
                </span>
              </div>
              <div className="flex items-center gap-2 truncate">
                <span className="w-2 h-2 rounded-full bg-[var(--color-primary)] shrink-0" />
                <span className="truncate font-semibold text-[var(--text-main)]">
                  <strong>Punto C (Destino):</strong> {destinoObj?.direccion || 'Taller / Entrega'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={toggleExpand}
              className="pointer-events-auto bg-[var(--bg-card)] hover:bg-[var(--bg-main)] text-[var(--text-main)] p-3 rounded-xl border border-[var(--bg-card-border)] shadow-lg active:scale-90 transition-all shrink-0 flex items-center justify-center"
              title={isExpanded ? 'Reducir Mapa' : 'Ampliar Mapa'}
            >
              {isExpanded ? (
                <Minimize2 className="w-5 h-5 text-[var(--color-primary)]" />
              ) : (
                <Maximize2 className="w-5 h-5 text-[var(--color-primary)]" />
              )}
            </button>
          </div>

          <iframe
            title="Mapa de Ruta de Servicio"
            width="100%"
            height="100%"
            className="w-full h-full border-0 grayscale-[15%] contrast-[105%]"
            loading="lazy"
            allowFullScreen
            src={mapEmbedUrl}
          />

          {isExpanded && (
            <div className="absolute bottom-4 left-4 right-4 z-20">
              <button
                type="button"
                onClick={toggleExpand}
                className="w-full py-3.5 bg-[var(--bg-card)] border border-[var(--bg-card-border)] text-[var(--text-main)] font-bold text-xs uppercase rounded-xl shadow-xl active:scale-95 transition-all"
              >
                Volver a la Vista Operativa
              </button>
            </div>
          )}
        </div>

        {!isExpanded && (
          <a
            href={gpsNavigationUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 bg-[var(--color-primary)] hover:opacity-90 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Navigation className="w-4 h-4 fill-current" />
            <span>RUTA GPS (A ➔ B ➔ C)</span>
          </a>
        )}
      </div>

      {isExpanded && (
        <div
          onClick={toggleExpand}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 animate-in fade-in duration-200"
        />
      )}
    </>
  );
}