// import { create } from 'zustand';
// import { db } from '../db/schema';

// export const ESTADOS_SERVICIO = {
//   IDLE: 'IDLE',
//   PENDIENTE_ACEPTACION: 'PENDIENTE_ACEPTACION',
//   ACEPTADO: 'ACEPTADO',
//   EN_CAMINO_ORIGEN: 'EN_CAMINO_ORIGEN',
//   EN_SITIO_ORIGEN: 'EN_SITIO_ORIGEN',
//   EN_CAMINO_DESTINO: 'EN_CAMINO_DESTINO',
//   PENDIENTE_EVIDENCIA: 'PENDIENTE_EVIDENCIA',
//   EXITO_SERVICIO: 'EXITO_SERVICIO'
// };

// export const useServiceStore = create((set, get) => ({
//   isOnline: navigator.onLine,
//   servicioActivo: null,
//   estadoActual: ESTADOS_SERVICIO.IDLE,

//   setIsOnline: (online) => set({ isOnline: online }),

//   cargarServicioPersistido: async () => {
//     try {
//       const servicios = await db.servicios.toArray();
//       const activo = servicios.find((s) => s.estado_actual !== ESTADOS_SERVICIO.EXITO_SERVICIO);
//       if (activo) {
//         set({ servicioActivo: activo, estadoActual: activo.estado_actual });
//       }
//     } catch (err) {
//       console.error('Error al cargar servicio guardado:', err);
//     }
//   },

//   asignarNuevoServicio: async (datosServicio) => {
//     const nuevoServicio = {
//       ...datosServicio,
//       estado_actual: ESTADOS_SERVICIO.PENDIENTE_ACEPTACION,
//       sincronizado: false
//     };
//     set({ servicioActivo: nuevoServicio, estadoActual: ESTADOS_SERVICIO.PENDIENTE_ACEPTACION });
//     try {
//       await db.servicios.put(nuevoServicio);
//     } catch (err) {
//       console.error('Error al guardar servicio inicial:', err);
//     }
//   },

//   aceptarServicioConGps: async (gpsGruero) => {
//     const { servicioActivo } = get();
//     if (!servicioActivo) return;

//     const servicioActualizado = {
//       ...servicioActivo,
//       estado_actual: ESTADOS_SERVICIO.ACEPTADO,
//       ubicacionGruero: gpsGruero,
//       sincronizado: false
//     };

//     // Actualización inmediata en React UI
//     set({
//       servicioActivo: servicioActualizado,
//       estadoActual: ESTADOS_SERVICIO.ACEPTADO
//     });

//     try {
//       await db.servicios.put(servicioActualizado);
//     } catch (err) {
//       console.error('Error al actualizar aceptación en IndexedDB:', err);
//     }
//   },

//   avanzarEstado: async (nuevoEstado) => {
//     const { servicioActivo } = get();
//     if (!servicioActivo) return;

//     const servicioActualizado = {
//       ...servicioActivo,
//       estado_actual: nuevoEstado,
//       sincronizado: false
//     };

//     // 1. ACTUALIZACIÓN INMEDIATA DE REACT UI (Sin latencia ni parpadeos)
//     set({
//       servicioActivo: servicioActualizado,
//       estadoActual: nuevoEstado
//     });

//     // 2. GUARDADO ASÍNCRONO SEGURO EN BACKGROUND
//     try {
//       await db.servicios.put(servicioActualizado);
//     } catch (err) {
//       console.error('Error al persistir estado en IndexedDB:', err);
//     }
//   },

//   cerrarServicio: async () => {
//     const { servicioActivo } = get();
//     set({ servicioActivo: null, estadoActual: ESTADOS_SERVICIO.IDLE });
//     if (servicioActivo) {
//       try {
//         await db.servicios.delete(servicioActivo.id);
//       } catch (err) {
//         console.error('Error al borrar servicio:', err);
//       }
//     }
//   }
// }));

import { create } from 'zustand';
import { db } from '../db/schema';

export const ESTADOS_SERVICIO = {
  IDLE: 'IDLE',
  PENDIENTE_ACEPTACION: 'PENDIENTE_ACEPTACION',
  ACEPTADO: 'ACEPTADO',
  EN_CAMINO_ORIGEN: 'EN_CAMINO_ORIGEN',
  EN_SITIO_ORIGEN: 'EN_SITIO_ORIGEN',
  EN_CAMINO_DESTINO: 'EN_CAMINO_DESTINO',
  PENDIENTE_EVIDENCIA: 'PENDIENTE_EVIDENCIA',
  EXITO_SERVICIO: 'EXITO_SERVICIO'
};

// Función auxiliar para formatear la duración en horas y minutos
export function formatearDuracion(minutosTotales) {
  if (!minutosTotales || minutosTotales < 1) return 'Menos de 1 min';
  const horas = Math.floor(minutosTotales / 60);
  const mins = minutosTotales % 60;
  if (horas === 0) return `${mins} min`;
  return `${horas}h ${mins}m`;
}

export const useServiceStore = create((set, get) => ({
  isOnline: navigator.onLine,
  servicioActivo: null,
  estadoActual: ESTADOS_SERVICIO.IDLE,
  tabActiva: 'jobs', // 'jobs' | 'map' | 'earnings' | 'profile'
  setTabActiva: (tab) => set({ tabActiva: tab }),

  setIsOnline: (online) => set({ isOnline: online }),

  cargarServicioPersistido: async () => {
    try {
      const servicios = await db.servicios.toArray();
      const activo = servicios.find((s) => s.estado_actual !== ESTADOS_SERVICIO.EXITO_SERVICIO);
      if (activo) {
        set({ servicioActivo: activo, estadoActual: activo.estado_actual });
      }
    } catch (err) {
      console.error('Error al cargar servicio guardado:', err);
    }
  },

  asignarNuevoServicio: async (datosServicio) => {
    const nuevoServicio = {
      ...datosServicio,
      estado_actual: ESTADOS_SERVICIO.PENDIENTE_ACEPTACION,
      sincronizado: false
    };
    set({ servicioActivo: nuevoServicio, estadoActual: ESTADOS_SERVICIO.PENDIENTE_ACEPTACION });
    try {
      await db.servicios.put(nuevoServicio);
    } catch (err) {
      console.error('Error al guardar servicio inicial:', err);
    }
  },

  aceptarServicioConGps: async (gpsGruero) => {
    const { servicioActivo } = get();
    if (!servicioActivo) return;

    const servicioActualizado = {
      ...servicioActivo,
      estado_actual: ESTADOS_SERVICIO.ACEPTADO,
      ubicacionGruero: gpsGruero,
      fecha_inicio: new Date().toISOString(), // <--- CAPTURA INICIO REAL DEL CRONÓMETRO
      sincronizado: false
    };

    set({
      servicioActivo: servicioActualizado,
      estadoActual: ESTADOS_SERVICIO.ACEPTADO
    });

    try {
      await db.servicios.put(servicioActualizado);
    } catch (err) {
      console.error('Error al actualizar aceptación:', err);
    }
  },

  avanzarEstado: async (nuevoEstado) => {
    const { servicioActivo } = get();
    if (!servicioActivo) return;

    let datosAdicionales = {};

    // Si el nuevo estado es el Cierre Exitoso, calculamos el tiempo total de atención
    if (nuevoEstado === ESTADOS_SERVICIO.EXITO_SERVICIO) {
      const fechaFin = new Date();
      const fechaInicio = servicioActivo.fecha_inicio 
        ? new Date(servicioActivo.fecha_inicio) 
        : new Date();

      const diferenciaMs = fechaFin.getTime() - fechaInicio.getTime();
      const minutosTranscurridos = Math.max(1, Math.round(diferenciaMs / (1000 * 60)));

      datosAdicionales = {
        fecha_fin: fechaFin.toISOString(),
        duracion_minutos: minutosTranscurridos
      };
    }

    const servicioActualizado = {
      ...servicioActivo,
      ...datosAdicionales,
      estado_actual: nuevoEstado,
      sincronizado: false
    };

    // Actualización síncrona inmediata en React
    set({
      servicioActivo: servicioActualizado,
      estadoActual: nuevoEstado
    });

    try {
      await db.servicios.put(servicioActualizado);
    } catch (err) {
      console.error('Error al persistir estado:', err);
    }
  },

  cerrarServicio: async () => {
    const { servicioActivo } = get();
    set({ servicioActivo: null, estadoActual: ESTADOS_SERVICIO.IDLE });
    if (servicioActivo) {
      try {
        await db.servicios.delete(servicioActivo.id);
      } catch (err) {
        console.error('Error al borrar servicio:', err);
      }
    }
  }
}));